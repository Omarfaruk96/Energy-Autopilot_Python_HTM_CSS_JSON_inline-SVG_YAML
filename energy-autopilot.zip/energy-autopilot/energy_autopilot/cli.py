"""Command line interface: python -m energy_autopilot <command>."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import List, Optional

from . import __version__
from .optimizer import DEFAULT_DEVICES, Device, build_plan, load_devices
from .prices import ZONES, PriceSeries, fetch_entsoe, load_csv, save_csv, simulate
from .report import render_html, render_text


def _get_series(args: argparse.Namespace) -> PriceSeries:
    if args.source == "sim":
        return simulate(days=args.days, slot_minutes=args.slot_minutes, seed=args.seed)
    if args.source == "csv":
        if not args.csv:
            raise SystemExit("--csv PATH is required with --source csv")
        return load_csv(args.csv)
    return fetch_entsoe(args.zone, date.today(), args.days, token=args.token, tz=args.tz)


def _devices(path: Optional[str]) -> List[Device]:
    return load_devices(path) if path else list(DEFAULT_DEVICES)


def _run_plan(args: argparse.Namespace) -> int:
    series = _get_series(args)
    plan = build_plan(series, _devices(args.config))
    print(render_text(plan, series))
    if args.out:
        Path(args.out).write_text(render_html(plan, series), encoding="utf-8")
        print(f"\nHTML report written to {args.out}")
    if args.json:
        Path(args.json).write_text(json.dumps(plan.to_dict(), indent=2), encoding="utf-8")
        print(f"Schedule JSON written to {args.json}")
    return 0


def _run_fetch(args: argparse.Namespace) -> int:
    series = fetch_entsoe(args.zone, date.today(), args.days, token=args.token, tz=args.tz)
    save_csv(series, args.out)
    print(f"Saved {len(series)} prices ({series.slot_minutes}-min slots) to {args.out}")
    return 0


def _run_zones(_: argparse.Namespace) -> int:
    for name, eic in ZONES.items():
        print(f"{name:<7}{eic}")
    return 0


def _common_source_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--source", choices=["sim", "csv", "entsoe"], default="sim", help="price source (default: sim)")
    p.add_argument("--csv", help="CSV file with columns start,price_eur_mwh")
    p.add_argument("--zone", default="SE3", help="bidding zone alias or EIC code (entsoe)")
    p.add_argument("--token", help="ENTSO-E token (or set ENTSOE_API_TOKEN)")
    p.add_argument("--tz", default="Europe/Stockholm", help="local timezone for entsoe data")
    p.add_argument("--days", type=int, default=7, help="number of days (default: 7)")
    p.add_argument("--slot-minutes", type=int, default=60, choices=[15, 30, 60], help="simulator slot length")
    p.add_argument("--seed", type=int, default=42, help="simulator seed")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="energy-autopilot", description=__doc__)
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo", help="run on simulated prices and write report.html")
    demo.add_argument("--days", type=int, default=7)
    demo.add_argument("--out", default="report.html")
    demo.set_defaults(func=lambda a: _run_plan(argparse.Namespace(
        source="sim", csv=None, zone="SIM", token=None, tz="UTC", days=a.days,
        slot_minutes=60, seed=42, config=None, out=a.out, json=None)))

    plan = sub.add_parser("plan", help="build a schedule from a price source")
    _common_source_args(plan)
    plan.add_argument("--config", help="devices JSON (default: built-in example devices)")
    plan.add_argument("--out", help="write an HTML report")
    plan.add_argument("--json", help="write the schedule as JSON (for automations)")
    plan.set_defaults(func=_run_plan)

    fetch = sub.add_parser("fetch", help="download day-ahead prices from ENTSO-E to CSV")
    fetch.add_argument("--zone", default="SE3")
    fetch.add_argument("--days", type=int, default=2)
    fetch.add_argument("--token")
    fetch.add_argument("--tz", default="Europe/Stockholm")
    fetch.add_argument("--out", default="prices.csv")
    fetch.set_defaults(func=_run_fetch)

    zones = sub.add_parser("zones", help="list built-in bidding-zone aliases")
    zones.set_defaults(func=_run_zones)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (RuntimeError, ValueError, OSError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
