"""Scheduling logic: pick the cheapest slots for each flexible load."""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from .prices import PricePoint, PriceSeries


@dataclass(frozen=True)
class Device:
    """A flexible load that must run `runtime_hours` per day inside a daily window.

    window_start/window_end are hours of day (0-24). If window_end <= window_start
    the window wraps past midnight (e.g. 18 -> 7 for an EV that charges overnight).
    contiguous=True forces one uninterrupted block (e.g. a dishwasher cycle).
    """

    name: str
    power_kw: float
    runtime_hours: float
    window_start: int = 0
    window_end: int = 24
    contiguous: bool = False

    def validate(self) -> None:
        if not self.name:
            raise ValueError("device needs a name")
        if self.power_kw <= 0:
            raise ValueError(f"{self.name}: power_kw must be > 0")
        if self.runtime_hours <= 0:
            raise ValueError(f"{self.name}: runtime_hours must be > 0")
        for label, h in (("window_start", self.window_start), ("window_end", self.window_end)):
            if not 0 <= h <= 24:
                raise ValueError(f"{self.name}: {label} must be between 0 and 24")
        span = (self.window_end - self.window_start) % 24 or 24
        if self.runtime_hours > span:
            raise ValueError(f"{self.name}: runtime_hours ({self.runtime_hours}) exceeds window ({span} h)")


DEFAULT_DEVICES: List[Device] = [
    Device("EV charger", power_kw=7.4, runtime_hours=4, window_start=18, window_end=7),
    Device("Water heater", power_kw=2.0, runtime_hours=3, window_start=0, window_end=24),
    Device("Heat pump boost", power_kw=3.0, runtime_hours=2, window_start=0, window_end=24),
    Device("Dishwasher", power_kw=1.2, runtime_hours=2, window_start=20, window_end=7, contiguous=True),
]


def load_devices(path: str | Path) -> List[Device]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    devices = [Device(**d) for d in data["devices"]]
    for d in devices:
        d.validate()
    return devices


@dataclass
class ScheduledRun:
    device: str
    day: date
    slots: List[datetime]
    energy_kwh: float
    cost_eur: float
    baseline_slots: List[datetime]
    baseline_cost_eur: float

    @property
    def saving_eur(self) -> float:
        return self.baseline_cost_eur - self.cost_eur

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device": self.device,
            "day": self.day.isoformat(),
            "slots": [s.isoformat(timespec="minutes") for s in self.slots],
            "energy_kwh": round(self.energy_kwh, 3),
            "cost_eur": round(self.cost_eur, 4),
            "baseline_cost_eur": round(self.baseline_cost_eur, 4),
            "saving_eur": round(self.saving_eur, 4),
        }


@dataclass
class Plan:
    runs: List[ScheduledRun] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)

    @property
    def cost_eur(self) -> float:
        return sum(r.cost_eur for r in self.runs)

    @property
    def baseline_cost_eur(self) -> float:
        return sum(r.baseline_cost_eur for r in self.runs)

    @property
    def saving_eur(self) -> float:
        return self.baseline_cost_eur - self.cost_eur

    @property
    def saving_pct(self) -> float:
        b = self.baseline_cost_eur
        return 100 * self.saving_eur / b if b > 0 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_cost_eur": round(self.cost_eur, 4),
            "baseline_cost_eur": round(self.baseline_cost_eur, 4),
            "saving_eur": round(self.saving_eur, 4),
            "saving_pct": round(self.saving_pct, 2),
            "runs": [r.to_dict() for r in self.runs],
            "skipped": self.skipped,
        }


def _window_bounds(day: date, d: Device) -> tuple[datetime, datetime]:
    start = datetime.combine(day, time.min) + timedelta(hours=d.window_start)
    end = datetime.combine(day, time.min) + timedelta(hours=d.window_end)
    if d.window_end <= d.window_start:
        end += timedelta(days=1)
    return start, end


def _cost(points: List[PricePoint], kwh_per_slot: float) -> float:
    return sum(kwh_per_slot * p.price_eur_mwh / 1000.0 for p in points)


def _is_block(points: List[PricePoint], step: timedelta) -> bool:
    return all(b.start - a.start == step for a, b in zip(points, points[1:]))


def _cheapest(points: List[PricePoint], k: int, contiguous: bool, step: timedelta) -> List[PricePoint]:
    if contiguous:
        best: Optional[List[PricePoint]] = None
        best_sum = math.inf
        for i in range(len(points) - k + 1):
            block = points[i : i + k]
            if not _is_block(block, step):
                continue
            s = sum(p.price_eur_mwh for p in block)
            if s < best_sum:
                best, best_sum = block, s
        return best or []
    return sorted(sorted(points, key=lambda p: (p.price_eur_mwh, p.start))[:k], key=lambda p: p.start)


def plan_device(series: PriceSeries, device: Device, day: date) -> Optional[ScheduledRun]:
    """Schedule one device for one day. Returns None if price data is incomplete."""
    start, end = _window_bounds(day, device)
    window = series.window(start, end)
    k = math.ceil(device.runtime_hours * 60 / series.slot_minutes - 1e-9)
    expected = int((end - start).total_seconds() // 60 // series.slot_minutes)
    if len(window) < expected or len(window) < k:
        return None  # not all prices are known yet (e.g. tomorrow's window)
    kwh_per_slot = device.power_kw * series.slot_minutes / 60
    chosen = _cheapest(window, k, device.contiguous, series.slot)
    if len(chosen) != k:
        return None
    baseline = window[:k]  # naive behaviour: start as soon as the window opens
    return ScheduledRun(
        device=device.name,
        day=day,
        slots=[p.start for p in chosen],
        energy_kwh=kwh_per_slot * k,
        cost_eur=_cost(chosen, kwh_per_slot),
        baseline_slots=[p.start for p in baseline],
        baseline_cost_eur=_cost(baseline, kwh_per_slot),
    )


def build_plan(series: PriceSeries, devices: List[Device]) -> Plan:
    plan = Plan()
    for device in devices:
        device.validate()
        for day in series.days():
            run = plan_device(series, device, day)
            if run is None:
                plan.skipped.append(f"{device.name} on {day.isoformat()} (incomplete price window)")
            else:
                plan.runs.append(run)
    plan.runs.sort(key=lambda r: (r.day, r.slots[0]))
    return plan
