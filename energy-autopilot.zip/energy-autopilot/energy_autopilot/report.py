"""Text and self-contained HTML reports (inline SVG, no external assets)."""
from __future__ import annotations

import html
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Dict, List

from .optimizer import Plan
from .prices import PriceSeries

PALETTE = ["#2563eb", "#16a34a", "#d97706", "#9333ea", "#dc2626", "#0891b2", "#be185d", "#4d7c0f"]


def _per_device(plan: Plan) -> "OrderedDict[str, Dict[str, float]]":
    out: "OrderedDict[str, Dict[str, float]]" = OrderedDict()
    for r in plan.runs:
        d = out.setdefault(r.device, {"runs": 0, "kwh": 0.0, "cost": 0.0, "base": 0.0})
        d["runs"] += 1
        d["kwh"] += r.energy_kwh
        d["cost"] += r.cost_eur
        d["base"] += r.baseline_cost_eur
    return out


def render_text(plan: Plan, series: PriceSeries) -> str:
    lines = [
        f"Energy Autopilot - zone {series.zone}, {len(series.days())} day(s), {series.slot_minutes}-min slots",
        "",
        f"{'Device':<18}{'Runs':>5}{'kWh':>9}{'Optim. EUR':>12}{'Base EUR':>11}{'Saved':>9}",
    ]
    for name, d in _per_device(plan).items():
        pct = 100 * (d["base"] - d["cost"]) / d["base"] if d["base"] > 0 else 0.0
        lines.append(
            f"{name:<18}{int(d['runs']):>5}{d['kwh']:>9.1f}{d['cost']:>12.2f}{d['base']:>11.2f}{pct:>8.1f}%"
        )
    lines += [
        "-" * 64,
        f"{'TOTAL':<18}{len(plan.runs):>5}{sum(r.energy_kwh for r in plan.runs):>9.1f}"
        f"{plan.cost_eur:>12.2f}{plan.baseline_cost_eur:>11.2f}{plan.saving_pct:>8.1f}%",
    ]
    if plan.skipped:
        lines += ["", f"Skipped {len(plan.skipped)} run(s) with incomplete price data."]
    return "\n".join(lines)


def _svg_chart(plan: Plan, series: PriceSeries, names: List[str]) -> str:
    W, left, right, top = 980, 56, 16, 12
    plot_w, plot_h = W - left - right, 220
    lane_h, lane_gap = 14, 6
    lanes_top = top + plot_h + 28
    H = lanes_top + len(names) * (lane_h + lane_gap) + 10

    t0 = series.points[0].start
    total = (series.points[-1].start + series.slot - t0).total_seconds()

    def x(t: datetime) -> float:
        return left + (t - t0).total_seconds() / total * plot_w

    prices = [p.price_eur_mwh for p in series.points]
    lo, hi = min(prices + [0.0]), max(prices)
    span = (hi - lo) or 1.0

    def y(v: float) -> float:
        return top + plot_h - (v - lo) / span * plot_h

    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Price curve with scheduled runs" class="chart">']
    for i in range(5):  # y grid
        v = lo + span * i / 4
        out.append(f'<line x1="{left}" x2="{W - right}" y1="{y(v):.1f}" y2="{y(v):.1f}" class="grid"/>')
        out.append(f'<text x="{left - 8}" y="{y(v) + 4:.1f}" class="axis" text-anchor="end">{v:.0f}</text>')
    day = datetime.combine(t0.date(), datetime.min.time())
    while day < t0 + timedelta(seconds=total):  # day separators
        if day >= t0:
            out.append(f'<line x1="{x(day):.1f}" x2="{x(day):.1f}" y1="{top}" y2="{lanes_top - 8}" class="day"/>')
        out.append(f'<text x="{max(x(day), left) + 4:.1f}" y="{top + plot_h + 16}" class="axis">{day:%a %d %b}</text>')
        day += timedelta(days=1)
    pts = " ".join(f"{x(p.start) + series.slot.total_seconds() / total * plot_w / 2:.1f},{y(p.price_eur_mwh):.1f}" for p in series.points)
    out.append(f'<polyline points="{pts}" class="price"/>')
    out.append(f'<text x="14" y="{top + 10}" class="axis" transform="rotate(-90 14 {top + plot_h / 2})" text-anchor="middle">EUR/MWh</text>')

    slot_w = max(series.slot.total_seconds() / total * plot_w, 1.0)
    for i, name in enumerate(names):
        ly = lanes_top + i * (lane_h + lane_gap)
        color = PALETTE[i % len(PALETTE)]
        out.append(f'<text x="{left - 8}" y="{ly + 11}" class="axis" text-anchor="end">{html.escape(name[:10])}</text>')
        out.append(f'<rect x="{left}" y="{ly}" width="{plot_w}" height="{lane_h}" class="lane"/>')
        for r in plan.runs:
            if r.device != name:
                continue
            for s in r.slots:
                out.append(f'<rect x="{x(s):.1f}" y="{ly}" width="{slot_w:.1f}" height="{lane_h}" fill="{color}"/>')
    out.append("</svg>")
    return "\n".join(out)


def render_html(plan: Plan, series: PriceSeries) -> str:
    per = _per_device(plan)
    names = list(per.keys())
    rows = []
    for i, (name, d) in enumerate(per.items()):
        pct = 100 * (d["base"] - d["cost"]) / d["base"] if d["base"] > 0 else 0.0
        rows.append(
            f'<tr><td><span class="dot" style="background:{PALETTE[i % len(PALETTE)]}"></span>{html.escape(name)}</td>'
            f'<td>{int(d["runs"])}</td><td>{d["kwh"]:.1f}</td><td>{d["cost"]:.2f}</td>'
            f'<td>{d["base"]:.2f}</td><td>{pct:.1f}%</td></tr>'
        )
    chart = _svg_chart(plan, series, names) if names else "<p>No complete price windows to plan.</p>"
    skipped = f"<p class='note'>{len(plan.skipped)} run(s) skipped: price data incomplete.</p>" if plan.skipped else ""
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Energy Autopilot report</title>
<style>
:root {{ --bg:#ffffff; --fg:#111827; --muted:#6b7280; --card:#f3f4f6; --line:#e5e7eb; --price:#111827; }}
@media (prefers-color-scheme: dark) {{ :root {{ --bg:#0f172a; --fg:#e5e7eb; --muted:#94a3b8; --card:#1e293b; --line:#334155; --price:#e5e7eb; }} }}
body {{ margin:0; padding:24px; background:var(--bg); color:var(--fg); font:15px/1.5 system-ui,sans-serif; }}
main {{ max-width:1000px; margin:auto; }}
h1 {{ margin:0 0 4px; font-size:24px; }} .sub {{ color:var(--muted); margin:0 0 20px; }}
.cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:12px; margin-bottom:20px; }}
.card {{ background:var(--card); border-radius:10px; padding:14px 16px; }}
.card b {{ display:block; font-size:22px; }} .card span {{ color:var(--muted); font-size:13px; }}
.chart {{ width:100%; height:auto; }} .grid {{ stroke:var(--line); }} .day {{ stroke:var(--line); stroke-dasharray:3 3; }}
.axis {{ fill:var(--muted); font-size:11px; }} .price {{ fill:none; stroke:var(--price); stroke-width:1.5; }} .lane {{ fill:var(--card); }}
.scroll {{ overflow-x:auto; }} table {{ border-collapse:collapse; width:100%; min-width:520px; margin-top:16px; }}
th,td {{ text-align:right; padding:8px 10px; border-bottom:1px solid var(--line); }} th:first-child,td:first-child {{ text-align:left; }}
.dot {{ display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:8px; }} .note {{ color:var(--muted); }}
</style></head><body><main>
<h1>Energy Autopilot</h1>
<p class="sub">Zone {html.escape(series.zone)} &middot; {len(series.days())} day(s) &middot; {series.slot_minutes}-minute slots &middot; costs in EUR</p>
<div class="cards">
<div class="card"><b>{plan.cost_eur:.2f}</b><span>Optimized cost</span></div>
<div class="card"><b>{plan.baseline_cost_eur:.2f}</b><span>Naive baseline cost</span></div>
<div class="card"><b>{plan.saving_eur:.2f}</b><span>Saved</span></div>
<div class="card"><b>{plan.saving_pct:.1f}%</b><span>Saving vs baseline</span></div>
</div>
<div class="scroll">{chart}</div>
<div class="scroll"><table><thead><tr><th>Device</th><th>Runs</th><th>kWh</th><th>Optimized</th><th>Baseline</th><th>Saved</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table></div>
{skipped}
<p class="note">Baseline = each device starts as soon as its allowed window opens. Energy cost only; grid fees and taxes excluded.</p>
</main></body></html>
"""
