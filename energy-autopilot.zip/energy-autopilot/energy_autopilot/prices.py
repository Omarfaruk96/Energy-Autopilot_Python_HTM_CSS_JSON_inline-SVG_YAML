"""Price sources: built-in simulator, CSV files and the ENTSO-E Transparency Platform."""
from __future__ import annotations

import csv
import math
import os
import random
import re
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

ENTSOE_URL = "https://web-api.tp.entsoe.eu/api"

# Example bidding-zone EIC codes. Any valid EIC code from the ENTSO-E
# documentation can be passed with --zone, these are just convenient aliases.
ZONES: Dict[str, str] = {
    "SE1": "10Y1001A1001A44P",
    "SE2": "10Y1001A1001A45N",
    "SE3": "10Y1001A1001A46L",
    "SE4": "10Y1001A1001A47J",
    "NO1": "10YNO-1--------2",
    "NO2": "10YNO-2--------T",
    "NO3": "10YNO-3--------J",
    "NO4": "10YNO-4--------9",
    "NO5": "10Y1001A1001A48H",
    "DK1": "10YDK-1--------W",
    "DK2": "10YDK-2--------M",
    "FI": "10YFI-1--------U",
    "DE-LU": "10Y1001A1001A82H",
    "NL": "10YNL----------L",
    "FR": "10YFR-RTE------C",
}


@dataclass(frozen=True)
class PricePoint:
    start: datetime  # naive, local time of the price zone
    price_eur_mwh: float


@dataclass
class PriceSeries:
    points: List[PricePoint]
    slot_minutes: int = 60
    zone: str = "SIM"
    _by_start: Dict[datetime, float] = field(init=False, repr=False, default_factory=dict)

    def __post_init__(self) -> None:
        dedup: Dict[datetime, float] = {}
        for p in sorted(self.points, key=lambda p: p.start):
            dedup.setdefault(p.start, p.price_eur_mwh)  # DST fall-back: keep first
        self.points = [PricePoint(s, v) for s, v in dedup.items()]
        self._by_start = dedup

    @property
    def slot(self) -> timedelta:
        return timedelta(minutes=self.slot_minutes)

    def window(self, start: datetime, end: datetime) -> List[PricePoint]:
        """Points with start <= point.start < end, in time order."""
        return [p for p in self.points if start <= p.start < end]

    def days(self) -> List[date]:
        return sorted({p.start.date() for p in self.points})

    def __len__(self) -> int:
        return len(self.points)


# --------------------------------------------------------------------------- simulator
def simulate(
    days: int = 7,
    start: Optional[date] = None,
    slot_minutes: int = 60,
    seed: int = 42,
    zone: str = "SIM",
) -> PriceSeries:
    """Deterministic synthetic prices with morning/evening peaks, a night dip,
    a solar dip around noon, day-to-day regime changes and rare spikes."""
    if slot_minutes <= 0 or 60 % slot_minutes != 0:
        raise ValueError("slot_minutes must divide 60 (e.g. 15, 30, 60)")
    rng = random.Random(seed)
    first = datetime.combine(start or date.today(), time.min)
    n = days * 24 * 60 // slot_minutes
    points: List[PricePoint] = []
    day_level = 0.0
    for i in range(n):
        t = first + timedelta(minutes=i * slot_minutes)
        if t.hour == 0 and t.minute == 0:
            day_level = rng.gauss(0, 25)
        h = t.hour + t.minute / 60
        price = (
            70
            + day_level
            + 35 * math.exp(-((h - 8) ** 2) / 4)
            + 55 * math.exp(-((h - 18.5) ** 2) / 5)
            - 20 * math.exp(-((h - 3) ** 2) / 8)
            - 18 * math.exp(-((h - 13) ** 2) / 6)
            - (10 if t.weekday() >= 5 else 0)
            + rng.gauss(0, 6)
        )
        if rng.random() < 0.01:
            price += rng.uniform(80, 250)
        points.append(PricePoint(t, round(price, 2)))
    return PriceSeries(points, slot_minutes, zone)


# --------------------------------------------------------------------------- CSV
def save_csv(series: PriceSeries, path: str | Path) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["start", "price_eur_mwh"])
        for p in series.points:
            w.writerow([p.start.isoformat(timespec="minutes"), p.price_eur_mwh])


def load_csv(path: str | Path, zone: str = "CSV") -> PriceSeries:
    points: List[PricePoint] = []
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            points.append(
                PricePoint(datetime.fromisoformat(row["start"]), float(row["price_eur_mwh"]))
            )
    if len(points) < 2:
        raise ValueError(f"{path}: need at least two price rows")
    points.sort(key=lambda p: p.start)
    minutes = int((points[1].start - points[0].start).total_seconds() // 60)
    if minutes <= 0:
        raise ValueError(f"{path}: timestamps must be strictly increasing")
    return PriceSeries(points, minutes, zone)


# --------------------------------------------------------------------------- ENTSO-E
def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child(el: ET.Element, name: str) -> Optional[ET.Element]:
    for c in el:
        if _local(c.tag) == name:
            return c
    return None


def _parse_ts(text: str) -> datetime:
    return datetime.strptime(text, "%Y-%m-%dT%H:%MZ").replace(tzinfo=timezone.utc)


def _resolution_minutes(text: str) -> int:
    m = re.fullmatch(r"PT(\d+)M", text.strip())
    if m:
        return int(m.group(1))
    if text.strip() == "PT1H":
        return 60
    raise ValueError(f"Unsupported resolution: {text}")


def parse_entsoe_xml(xml_text: str, tz: Optional[str] = None, zone: str = "ENTSOE") -> PriceSeries:
    """Parse an ENTSO-E day-ahead price document (documentType A44).

    Handles missing points (forward fill) and mixed 60/15 minute resolutions by
    resampling everything to the finest resolution found.
    """
    root = ET.fromstring(xml_text)
    if _local(root.tag) == "Acknowledgement_MarketDocument":
        reason = next((e.text for e in root.iter() if _local(e.tag) == "text"), "unknown reason")
        raise RuntimeError(f"ENTSO-E returned no data: {reason}")

    segments = []  # (start_utc, minutes, price)
    for ts in root.iter():
        if _local(ts.tag) != "TimeSeries":
            continue
        for period in ts:
            if _local(period.tag) != "Period":
                continue
            interval = _child(period, "timeInterval")
            res = _child(period, "resolution")
            if interval is None or res is None:
                continue
            start = _parse_ts(_child(interval, "start").text)
            end = _parse_ts(_child(interval, "end").text)
            minutes = _resolution_minutes(res.text)
            n = int((end - start).total_seconds() // 60 // minutes)
            values: Dict[int, float] = {}
            for pt in period:
                if _local(pt.tag) != "Point":
                    continue
                values[int(_child(pt, "position").text)] = float(_child(pt, "price.amount").text)
            last = None
            for pos in range(1, n + 1):
                last = values.get(pos, last)
                if last is not None:
                    segments.append((start + timedelta(minutes=minutes * (pos - 1)), minutes, last))
    if not segments:
        raise RuntimeError("No price points found in ENTSO-E response")

    target = min(m for _, m, _ in segments)
    zinfo = None
    if tz:
        try:
            from zoneinfo import ZoneInfo

            zinfo = ZoneInfo(tz)
        except Exception:  # missing tzdata etc.
            zinfo = None
    points: List[PricePoint] = []
    for start, minutes, price in segments:
        for k in range(minutes // target):
            t = start + timedelta(minutes=k * target)
            if zinfo is not None:
                t = t.astimezone(zinfo)
            points.append(PricePoint(t.replace(tzinfo=None), price))
    return PriceSeries(points, target, zone)


def fetch_entsoe(
    zone: str,
    start_day: date,
    days: int,
    token: Optional[str] = None,
    tz: str = "Europe/Stockholm",
) -> PriceSeries:
    token = token or os.environ.get("ENTSOE_API_TOKEN")
    if not token:
        raise RuntimeError(
            "ENTSO-E needs an API token. Set ENTSOE_API_TOKEN or pass --token "
            "(free registration at transparency.entsoe.eu)."
        )
    eic = ZONES.get(zone.upper(), zone)
    try:
        from zoneinfo import ZoneInfo

        local = ZoneInfo(tz)
        begin = datetime.combine(start_day, time.min, tzinfo=local).astimezone(timezone.utc)
        finish = datetime.combine(start_day + timedelta(days=days), time.min, tzinfo=local).astimezone(
            timezone.utc
        )
    except Exception:
        begin = datetime.combine(start_day, time.min, tzinfo=timezone.utc)
        finish = begin + timedelta(days=days)
    params = {
        "securityToken": token,
        "documentType": "A44",
        "in_Domain": eic,
        "out_Domain": eic,
        "periodStart": begin.strftime("%Y%m%d%H%M"),
        "periodEnd": finish.strftime("%Y%m%d%H%M"),
    }
    url = f"{ENTSOE_URL}?{urllib.parse.urlencode(params)}"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"ENTSO-E request failed: HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach ENTSO-E: {exc.reason}") from exc
    return parse_entsoe_xml(body, tz=tz, zone=zone.upper())
