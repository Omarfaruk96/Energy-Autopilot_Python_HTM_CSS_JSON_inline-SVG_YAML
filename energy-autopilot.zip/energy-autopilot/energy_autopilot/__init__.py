"""Energy Autopilot - schedule flexible loads around electricity spot prices."""

__version__ = "0.1.0"
