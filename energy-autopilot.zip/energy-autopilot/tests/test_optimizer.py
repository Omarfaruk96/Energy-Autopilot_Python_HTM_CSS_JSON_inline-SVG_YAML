import unittest
from datetime import date, datetime, timedelta

from energy_autopilot.optimizer import Device, build_plan, plan_device
from energy_autopilot.prices import PricePoint, PriceSeries, simulate

DAY = date(2025, 1, 6)


def make_series(prices, start=datetime(2025, 1, 6), minutes=60):
    pts = [PricePoint(start + timedelta(minutes=minutes * i), p) for i, p in enumerate(prices)]
    return PriceSeries(pts, minutes, "TEST")


class OptimizerTests(unittest.TestCase):
    def test_picks_cheapest_slots(self):
        prices = [50] * 24
        prices[3], prices[4], prices[14] = 5, 6, 1
        series = make_series(prices)
        run = plan_device(series, Device("x", 1.0, 3), DAY)
        self.assertEqual([s.hour for s in run.slots], [3, 4, 14])
        self.assertAlmostEqual(run.cost_eur, (5 + 6 + 1) / 1000)

    def test_contiguous_block(self):
        prices = [50] * 24
        prices[3], prices[4], prices[14] = 5, 6, 1  # cheapest single hour is isolated
        run = plan_device(make_series(prices), Device("x", 1.0, 2, contiguous=True), DAY)
        self.assertEqual([s.hour for s in run.slots], [3, 4])

    def test_window_wraps_past_midnight(self):
        prices = [100] * 48
        prices[26] = 1  # 02:00 next day
        series = make_series(prices)
        run = plan_device(series, Device("ev", 7.4, 1, window_start=18, window_end=7), DAY)
        self.assertEqual(run.slots[0], datetime(2025, 1, 7, 2))

    def test_never_worse_than_baseline(self):
        series = simulate(days=14, start=DAY, seed=7)
        devices = [
            Device("a", 2.0, 3),
            Device("b", 7.4, 4, window_start=18, window_end=7),
            Device("c", 1.2, 2, window_start=20, window_end=7, contiguous=True),
        ]
        plan = build_plan(series, devices)
        self.assertTrue(plan.runs)
        for run in plan.runs:
            self.assertLessEqual(run.cost_eur, run.baseline_cost_eur + 1e-9)

    def test_incomplete_window_is_skipped(self):
        series = make_series([40] * 31)  # day 1 complete, day 2 has only 7 hours
        plan = build_plan(series, [Device("ev", 7.4, 2, window_start=18, window_end=7)])
        self.assertEqual(len(plan.runs), 1)  # day 1 window (18:00 -> 07:00) is fully known
        self.assertEqual(len(plan.skipped), 1)  # day 2 window is not

    def test_quarter_hour_slots(self):
        prices = [80.0] * 96
        prices[10] = prices[11] = -20.0  # negative prices are welcome
        series = make_series(prices, minutes=15)
        run = plan_device(series, Device("x", 4.0, 0.5), DAY)
        self.assertEqual(len(run.slots), 2)
        self.assertLess(run.cost_eur, 0)

    def test_validation(self):
        with self.assertRaises(ValueError):
            Device("x", 1.0, 30).validate()
        with self.assertRaises(ValueError):
            Device("x", -1.0, 1).validate()


if __name__ == "__main__":
    unittest.main()
