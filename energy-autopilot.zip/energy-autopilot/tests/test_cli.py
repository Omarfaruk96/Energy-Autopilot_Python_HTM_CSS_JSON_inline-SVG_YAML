import json
import os
import tempfile
import unittest

from energy_autopilot.cli import main


class CliTests(unittest.TestCase):
    def test_demo_writes_report(self):
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "r.html")
            self.assertEqual(main(["demo", "--out", out]), 0)
            with open(out, encoding="utf-8") as fh:
                self.assertIn("<svg", fh.read())

    def test_plan_json_with_config(self):
        with tempfile.TemporaryDirectory() as d:
            js = os.path.join(d, "s.json")
            cfg = os.path.join(os.path.dirname(__file__), "..", "examples", "devices.json")
            self.assertEqual(main(["plan", "--config", cfg, "--days", "3", "--json", js]), 0)
            with open(js, encoding="utf-8") as fh:
                data = json.load(fh)
            self.assertGreater(data["saving_eur"], 0)

    def test_entsoe_without_token_fails_cleanly(self):
        os.environ.pop("ENTSOE_API_TOKEN", None)
        self.assertEqual(main(["plan", "--source", "entsoe"]), 1)


if __name__ == "__main__":
    unittest.main()
