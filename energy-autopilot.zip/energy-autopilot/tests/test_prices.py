import os
import tempfile
import unittest
from datetime import date, datetime

from energy_autopilot.prices import load_csv, parse_entsoe_xml, save_csv, simulate

SAMPLE_XML = """<?xml version="1.0" encoding="UTF-8"?>
<Publication_MarketDocument xmlns="urn:iec62325.351:tc57wg16:451-3:publicationdocument:7:3">
  <TimeSeries>
    <Period>
      <timeInterval><start>2025-01-05T23:00Z</start><end>2025-01-06T03:00Z</end></timeInterval>
      <resolution>PT60M</resolution>
      <Point><position>1</position><price.amount>10.5</price.amount></Point>
      <Point><position>2</position><price.amount>20.0</price.amount></Point>
      <Point><position>4</position><price.amount>40.0</price.amount></Point>
    </Period>
  </TimeSeries>
</Publication_MarketDocument>"""

MIXED_XML = """<?xml version="1.0" encoding="UTF-8"?>
<Publication_MarketDocument xmlns="urn:iec62325.351:tc57wg16:451-3:publicationdocument:7:3">
  <TimeSeries><Period>
    <timeInterval><start>2025-01-06T00:00Z</start><end>2025-01-06T01:00Z</end></timeInterval>
    <resolution>PT60M</resolution>
    <Point><position>1</position><price.amount>30</price.amount></Point>
  </Period></TimeSeries>
  <TimeSeries><Period>
    <timeInterval><start>2025-01-06T01:00Z</start><end>2025-01-06T02:00Z</end></timeInterval>
    <resolution>PT15M</resolution>
    <Point><position>1</position><price.amount>1</price.amount></Point>
    <Point><position>2</position><price.amount>2</price.amount></Point>
    <Point><position>3</position><price.amount>3</price.amount></Point>
    <Point><position>4</position><price.amount>4</price.amount></Point>
  </Period></TimeSeries>
</Publication_MarketDocument>"""

NO_DATA_XML = """<Acknowledgement_MarketDocument xmlns="urn:iec62325.351:tc57wg16:451-1:acknowledgementdocument:7:0">
  <Reason><code>999</code><text>No matching data found</text></Reason></Acknowledgement_MarketDocument>"""


class PriceTests(unittest.TestCase):
    def test_simulator_is_deterministic(self):
        a = simulate(days=3, start=date(2025, 1, 6), seed=1)
        b = simulate(days=3, start=date(2025, 1, 6), seed=1)
        c = simulate(days=3, start=date(2025, 1, 6), seed=2)
        self.assertEqual(a.points, b.points)
        self.assertNotEqual(a.points, c.points)
        self.assertEqual(len(a), 72)

    def test_csv_roundtrip(self):
        s = simulate(days=2, start=date(2025, 1, 6))
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "p.csv")
            save_csv(s, path)
            back = load_csv(path)
        self.assertEqual(len(back), len(s))
        self.assertEqual(back.slot_minutes, 60)
        self.assertEqual(back.points[5].price_eur_mwh, s.points[5].price_eur_mwh)

    def test_entsoe_parse_with_gap_forward_fill(self):
        s = parse_entsoe_xml(SAMPLE_XML)
        self.assertEqual([p.price_eur_mwh for p in s.points], [10.5, 20.0, 20.0, 40.0])
        self.assertEqual(s.slot_minutes, 60)

    def test_entsoe_timezone_conversion(self):
        s = parse_entsoe_xml(SAMPLE_XML, tz="Europe/Stockholm")
        if s.points[0].start.hour == 0:  # tzdata available: 23:00Z is 00:00 CET
            self.assertEqual(s.points[0].start, datetime(2025, 1, 6, 0, 0))

    def test_entsoe_mixed_resolution_resampled(self):
        s = parse_entsoe_xml(MIXED_XML)
        self.assertEqual(s.slot_minutes, 15)
        self.assertEqual([p.price_eur_mwh for p in s.points], [30] * 4 + [1, 2, 3, 4])

    def test_entsoe_ack_document_raises(self):
        with self.assertRaises(RuntimeError):
            parse_entsoe_xml(NO_DATA_XML)


if __name__ == "__main__":
    unittest.main()
