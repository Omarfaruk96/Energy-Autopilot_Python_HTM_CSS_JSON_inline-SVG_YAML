# Energy Autopilot

[![CI](https://github.com/YOUR_USERNAME/energy-autopilot/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/energy-autopilot/actions)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![Dependencies](https://img.shields.io/badge/runtime%20deps-0-brightgreen)
![License](https://img.shields.io/badge/license-MIT-lightgrey)

Schedule flexible electricity loads (EV charger, water heater, heat pump, dishwasher) around **spot prices**, and see how much cheaper that is than running them whenever they are needed.

Where electricity is sold at hourly (or 15-minute) spot prices, the cheapest and the most expensive hours of a day can differ several times over. Energy Autopilot reads those prices, respects each device's constraints (power, daily runtime, allowed time window, contiguous or interruptible) and produces a schedule, a savings report and a machine-readable JSON file you can feed into your own automation.

## Quick start (no setup, no API key)

```bash
git clone https://github.com/YOUR_USERNAME/energy-autopilot.git
cd energy-autopilot
./run_demo.sh            # Windows: double-click run_demo.bat
```

This generates a week of simulated prices, plans the example devices, prints a summary and writes `report.html` (open it in a browser).

Or with the CLI:

```bash
pip install .
energy-autopilot demo
energy-autopilot plan --config examples/devices.json --days 7 --out report.html --json schedule.json
```

Example output (simulated prices):

```
Device             Runs      kWh   Optim. EUR   Base EUR    Saved
Water heater          7     42.0         3.16       3.60    12.2%
Heat pump boost       7     42.0         3.11       3.78    17.8%
EV charger            6    177.6        12.80      25.99    50.8%
Dishwasher            6     14.4         0.98       2.04    52.2%
```

> The simulator produces plausible daily price shapes, not real market data. Savings figures from `demo` illustrate the mechanism; use real prices (below) for meaningful numbers.

## Real prices from ENTSO-E

1. Register at the [ENTSO-E Transparency Platform](https://transparency.entsoe.eu/) and request a RESTful API token.
2. Run:

```bash
export ENTSOE_API_TOKEN=your-token
energy-autopilot zones                                   # list zone aliases
energy-autopilot fetch --zone SE3 --days 2 --out prices.csv
energy-autopilot plan --source csv --csv prices.csv --config examples/devices.json --out report.html
# or fetch and plan in one go
energy-autopilot plan --source entsoe --zone NO2 --tz Europe/Oslo --days 2 --out report.html
```

Any bidding zone works: use an alias from `energy-autopilot zones` or pass an EIC code directly. Day-ahead prices for tomorrow are usually published around midday (CET); windows that are not fully known yet are skipped rather than guessed.

## Configure your devices

`examples/devices.json`:

```json
{"devices": [
  {"name": "EV charger", "power_kw": 7.4, "runtime_hours": 4, "window_start": 18, "window_end": 7},
  {"name": "Dishwasher", "power_kw": 1.2, "runtime_hours": 2, "window_start": 20, "window_end": 7, "contiguous": true}
]}
```

| Field | Meaning |
|---|---|
| `power_kw` | Draw while running |
| `runtime_hours` | Hours the device must run each day |
| `window_start`, `window_end` | Allowed hours of day (0-24). If `end <= start` the window wraps past midnight |
| `contiguous` | `true` = one uninterrupted block (dishwasher); `false` = any cheap slots (EV, water heater) |

## How it works

```mermaid
flowchart LR
    A[Prices: simulator / CSV / ENTSO-E] --> B[PriceSeries]
    C[devices.json] --> D[Optimizer]
    B --> D
    D --> E[Plan]
    E --> F[HTML report]
    E --> G[JSON schedule]
    G --> H[Home Assistant / MQTT / cron]
```

For each device and day, the optimizer takes the allowed window, then selects the cheapest `runtime_hours` worth of slots (or the cheapest contiguous block). The **baseline** is the naive behaviour: start as soon as the window opens. See [docs/architecture.md](docs/architecture.md) for design decisions.

The JSON output lists every run with its slots, energy and cost, so any scheduler can consume it:

```json
{"device": "EV charger", "day": "2026-10-11", "slots": ["2026-10-11T22:00", "..."], "energy_kwh": 29.6, "cost_eur": 2.1}
```

## Development

```bash
make test                         # python -m unittest discover -s tests -v
make demo
docker build -t energy-autopilot . && docker run --rm -v "$PWD/out:/out" energy-autopilot
```

The project has no runtime dependencies. CI runs the test suite on Python 3.9-3.13.

## Limitations

- Energy price only: grid fees, taxes and supplier margins are not included.
- Devices are optimized independently (no shared grid-connection limit, battery or thermal model yet).
- DST change days are approximated (see architecture notes).
- The ENTSO-E client is tested against sample documents; check it against the live API with your own token.

## Roadmap

- [ ] MILP/LP optimizer (PuLP / OR-Tools) with a shared fuse limit and battery storage
- [ ] Thermal model for heat pumps driven by weather forecasts (MET Norway, SMHI, Open-Meteo)
- [ ] Home Assistant / MQTT output
- [ ] Grid tariff and tax profiles
- [ ] FastAPI service with a live dashboard
- [ ] CO2-intensity as a second objective

## License

MIT
