# Changelog

## 0.1.0
- Price sources: simulator, CSV, ENTSO-E day-ahead (60 and 15 minute resolution)
- Per-device optimizer: cheapest slots or cheapest contiguous block, windows that wrap midnight
- Savings vs. naive "start immediately" baseline
- Self-contained HTML report and JSON schedule export
- Zero runtime dependencies, CI on Python 3.9-3.13
