@echo off
cd /d "%~dp0"
python -m energy_autopilot demo --out report.html
start report.html
