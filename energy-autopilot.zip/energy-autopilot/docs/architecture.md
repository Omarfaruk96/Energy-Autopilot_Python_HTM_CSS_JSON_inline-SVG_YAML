# Architecture

```mermaid
flowchart LR
    A[Price source<br/>simulator / CSV / ENTSO-E] --> B[PriceSeries<br/>normalized slots]
    C[devices.json] --> D[Optimizer]
    B --> D
    D --> E[Plan<br/>runs + savings]
    E --> F[HTML report]
    E --> G[JSON schedule]
    G --> H[Home Assistant / MQTT / cron<br/>your integration]
```

## Modules

| Module | Responsibility |
|---|---|
| `prices.py` | Load or generate prices; ENTSO-E XML parsing with gap fill and mixed 60/15-minute resampling |
| `optimizer.py` | `Device` model, per-day window selection, cheapest-slot and contiguous-block strategies, baseline comparison |
| `report.py` | Text summary and standalone HTML/SVG report |
| `cli.py` | `demo`, `plan`, `fetch`, `zones` commands |

## Design decisions

- **Zero dependencies.** Standard library only, so the project runs anywhere Python does.
- **Naive local timestamps.** Prices are converted to the zone's local time and stored without tzinfo. This keeps window logic simple; the trade-off is that DST change days (23/25 hours) are approximated (duplicate hour: first value kept).
- **Greedy per device, per day.** Each device is independent, which is optimal for non-contiguous loads with no coupling. Shared constraints (grid connection limit, battery state of charge) need an LP/MILP solver; see the roadmap.
- **Incomplete windows are skipped, not guessed.** If tomorrow's prices are not published yet, tomorrow's runs are reported as skipped.
