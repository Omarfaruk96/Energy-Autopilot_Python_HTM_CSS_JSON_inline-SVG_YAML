#!/usr/bin/env sh
# One-command demo: simulated prices -> schedule -> report.html
set -e
cd "$(dirname "$0")"
PY=$(command -v python3 || command -v python)
"$PY" -m energy_autopilot demo --out report.html
case "$(uname -s)" in
  Darwin) open report.html ;;
  Linux)  command -v xdg-open >/dev/null 2>&1 && xdg-open report.html >/dev/null 2>&1 || true ;;
esac
